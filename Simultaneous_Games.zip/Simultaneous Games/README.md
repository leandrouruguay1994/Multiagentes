# Ambiente

## crear el ambiente

`conda env create -f environment.yaml`

## activar el ambiente

`conda activate pettingzoo_games`